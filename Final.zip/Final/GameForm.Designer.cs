﻿namespace Final
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PB7Test = new System.Windows.Forms.PictureBox();
            this.PB4Test = new System.Windows.Forms.PictureBox();
            this.PB1Test = new System.Windows.Forms.PictureBox();
            this.PB1O = new System.Windows.Forms.PictureBox();
            this.PB1X = new System.Windows.Forms.PictureBox();
            this.PB2Test = new System.Windows.Forms.PictureBox();
            this.PB2X = new System.Windows.Forms.PictureBox();
            this.PB4O = new System.Windows.Forms.PictureBox();
            this.PB2O = new System.Windows.Forms.PictureBox();
            this.PB3Test = new System.Windows.Forms.PictureBox();
            this.PB3X = new System.Windows.Forms.PictureBox();
            this.PB3O = new System.Windows.Forms.PictureBox();
            this.PB4X = new System.Windows.Forms.PictureBox();
            this.PB5Test = new System.Windows.Forms.PictureBox();
            this.PB6Test = new System.Windows.Forms.PictureBox();
            this.PB8Test = new System.Windows.Forms.PictureBox();
            this.PB9Test = new System.Windows.Forms.PictureBox();
            this.PB5X = new System.Windows.Forms.PictureBox();
            this.PB5O = new System.Windows.Forms.PictureBox();
            this.PB6O = new System.Windows.Forms.PictureBox();
            this.PB6X = new System.Windows.Forms.PictureBox();
            this.PB7O = new System.Windows.Forms.PictureBox();
            this.PB7X = new System.Windows.Forms.PictureBox();
            this.PB8X = new System.Windows.Forms.PictureBox();
            this.PB9X = new System.Windows.Forms.PictureBox();
            this.PB8O = new System.Windows.Forms.PictureBox();
            this.PB9O = new System.Windows.Forms.PictureBox();
            this.column1Win = new System.Windows.Forms.Label();
            this.row2Win = new System.Windows.Forms.Label();
            this.row3Win = new System.Windows.Forms.Label();
            this.row1Win = new System.Windows.Forms.Label();
            this.column3Win = new System.Windows.Forms.Label();
            this.column2Win = new System.Windows.Forms.Label();
            this.pb1Win = new System.Windows.Forms.Label();
            this.pb5Win = new System.Windows.Forms.Label();
            this.pb9Win = new System.Windows.Forms.Label();
            this.pb3Win = new System.Windows.Forms.Label();
            this.pb7Win = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PB7Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB9Test)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB7O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB7X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB9X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8O)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB9O)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(192, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 452);
            this.label4.TabIndex = 3;
            this.label4.Text = "label4";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(401, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 452);
            this.label1.TabIndex = 4;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(7, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(598, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(12, 296);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(589, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "label3";
            // 
            // PB7Test
            // 
            this.PB7Test.Location = new System.Drawing.Point(7, 321);
            this.PB7Test.Name = "PB7Test";
            this.PB7Test.Size = new System.Drawing.Size(179, 117);
            this.PB7Test.TabIndex = 15;
            this.PB7Test.TabStop = false;
            this.PB7Test.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // PB4Test
            // 
            this.PB4Test.Location = new System.Drawing.Point(7, 167);
            this.PB4Test.Name = "PB4Test";
            this.PB4Test.Size = new System.Drawing.Size(179, 117);
            this.PB4Test.TabIndex = 16;
            this.PB4Test.TabStop = false;
            this.PB4Test.Click += new System.EventHandler(this.PB4Test_Click);
            // 
            // PB1Test
            // 
            this.PB1Test.Location = new System.Drawing.Point(12, 3);
            this.PB1Test.Name = "PB1Test";
            this.PB1Test.Size = new System.Drawing.Size(179, 117);
            this.PB1Test.TabIndex = 17;
            this.PB1Test.TabStop = false;
            this.PB1Test.Click += new System.EventHandler(this.PB1Test_Click);
            // 
            // PB1O
            // 
            this.PB1O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB1O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB1O.Location = new System.Drawing.Point(7, 3);
            this.PB1O.Name = "PB1O";
            this.PB1O.Size = new System.Drawing.Size(179, 117);
            this.PB1O.TabIndex = 18;
            this.PB1O.TabStop = false;
            this.PB1O.Visible = false;
            // 
            // PB1X
            // 
            this.PB1X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB1X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB1X.Location = new System.Drawing.Point(7, 3);
            this.PB1X.Name = "PB1X";
            this.PB1X.Size = new System.Drawing.Size(179, 117);
            this.PB1X.TabIndex = 19;
            this.PB1X.TabStop = false;
            this.PB1X.Visible = false;
            this.PB1X.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // PB2Test
            // 
            this.PB2Test.Location = new System.Drawing.Point(216, 3);
            this.PB2Test.Name = "PB2Test";
            this.PB2Test.Size = new System.Drawing.Size(179, 117);
            this.PB2Test.TabIndex = 20;
            this.PB2Test.TabStop = false;
            this.PB2Test.Click += new System.EventHandler(this.PB2_Click);
            // 
            // PB2X
            // 
            this.PB2X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB2X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB2X.Location = new System.Drawing.Point(216, 1);
            this.PB2X.Name = "PB2X";
            this.PB2X.Size = new System.Drawing.Size(179, 117);
            this.PB2X.TabIndex = 21;
            this.PB2X.TabStop = false;
            this.PB2X.Visible = false;
            // 
            // PB4O
            // 
            this.PB4O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB4O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB4O.Location = new System.Drawing.Point(7, 158);
            this.PB4O.Name = "PB4O";
            this.PB4O.Size = new System.Drawing.Size(179, 117);
            this.PB4O.TabIndex = 22;
            this.PB4O.TabStop = false;
            this.PB4O.Visible = false;
            // 
            // PB2O
            // 
            this.PB2O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB2O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB2O.Location = new System.Drawing.Point(216, 3);
            this.PB2O.Name = "PB2O";
            this.PB2O.Size = new System.Drawing.Size(179, 117);
            this.PB2O.TabIndex = 23;
            this.PB2O.TabStop = false;
            this.PB2O.Visible = false;
            // 
            // PB3Test
            // 
            this.PB3Test.Location = new System.Drawing.Point(426, 3);
            this.PB3Test.Name = "PB3Test";
            this.PB3Test.Size = new System.Drawing.Size(179, 117);
            this.PB3Test.TabIndex = 24;
            this.PB3Test.TabStop = false;
            this.PB3Test.Click += new System.EventHandler(this.PB3Test_Click);
            // 
            // PB3X
            // 
            this.PB3X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB3X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB3X.Location = new System.Drawing.Point(426, 3);
            this.PB3X.Name = "PB3X";
            this.PB3X.Size = new System.Drawing.Size(179, 117);
            this.PB3X.TabIndex = 25;
            this.PB3X.TabStop = false;
            this.PB3X.Visible = false;
            // 
            // PB3O
            // 
            this.PB3O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB3O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB3O.Location = new System.Drawing.Point(426, 3);
            this.PB3O.Name = "PB3O";
            this.PB3O.Size = new System.Drawing.Size(179, 117);
            this.PB3O.TabIndex = 26;
            this.PB3O.TabStop = false;
            this.PB3O.Visible = false;
            // 
            // PB4X
            // 
            this.PB4X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB4X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB4X.Location = new System.Drawing.Point(7, 158);
            this.PB4X.Name = "PB4X";
            this.PB4X.Size = new System.Drawing.Size(179, 117);
            this.PB4X.TabIndex = 27;
            this.PB4X.TabStop = false;
            this.PB4X.Visible = false;
            // 
            // PB5Test
            // 
            this.PB5Test.Location = new System.Drawing.Point(216, 167);
            this.PB5Test.Name = "PB5Test";
            this.PB5Test.Size = new System.Drawing.Size(179, 117);
            this.PB5Test.TabIndex = 28;
            this.PB5Test.TabStop = false;
            this.PB5Test.Click += new System.EventHandler(this.PB5Test_Click);
            // 
            // PB6Test
            // 
            this.PB6Test.Location = new System.Drawing.Point(426, 167);
            this.PB6Test.Name = "PB6Test";
            this.PB6Test.Size = new System.Drawing.Size(179, 117);
            this.PB6Test.TabIndex = 29;
            this.PB6Test.TabStop = false;
            this.PB6Test.Click += new System.EventHandler(this.PB6Test_Click);
            // 
            // PB8Test
            // 
            this.PB8Test.Location = new System.Drawing.Point(216, 321);
            this.PB8Test.Name = "PB8Test";
            this.PB8Test.Size = new System.Drawing.Size(179, 117);
            this.PB8Test.TabIndex = 30;
            this.PB8Test.TabStop = false;
            this.PB8Test.Click += new System.EventHandler(this.PB8Test_Click);
            // 
            // PB9Test
            // 
            this.PB9Test.Location = new System.Drawing.Point(426, 321);
            this.PB9Test.Name = "PB9Test";
            this.PB9Test.Size = new System.Drawing.Size(179, 117);
            this.PB9Test.TabIndex = 31;
            this.PB9Test.TabStop = false;
            this.PB9Test.Click += new System.EventHandler(this.PB9Test_Click);
            // 
            // PB5X
            // 
            this.PB5X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB5X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB5X.Location = new System.Drawing.Point(216, 167);
            this.PB5X.Name = "PB5X";
            this.PB5X.Size = new System.Drawing.Size(179, 117);
            this.PB5X.TabIndex = 32;
            this.PB5X.TabStop = false;
            this.PB5X.Visible = false;
            // 
            // PB5O
            // 
            this.PB5O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB5O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB5O.Location = new System.Drawing.Point(216, 167);
            this.PB5O.Name = "PB5O";
            this.PB5O.Size = new System.Drawing.Size(179, 117);
            this.PB5O.TabIndex = 33;
            this.PB5O.TabStop = false;
            this.PB5O.Visible = false;
            // 
            // PB6O
            // 
            this.PB6O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB6O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB6O.Location = new System.Drawing.Point(426, 167);
            this.PB6O.Name = "PB6O";
            this.PB6O.Size = new System.Drawing.Size(179, 117);
            this.PB6O.TabIndex = 34;
            this.PB6O.TabStop = false;
            this.PB6O.Visible = false;
            // 
            // PB6X
            // 
            this.PB6X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB6X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB6X.Location = new System.Drawing.Point(426, 167);
            this.PB6X.Name = "PB6X";
            this.PB6X.Size = new System.Drawing.Size(179, 117);
            this.PB6X.TabIndex = 35;
            this.PB6X.TabStop = false;
            this.PB6X.Visible = false;
            // 
            // PB7O
            // 
            this.PB7O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB7O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB7O.Location = new System.Drawing.Point(6, 321);
            this.PB7O.Name = "PB7O";
            this.PB7O.Size = new System.Drawing.Size(179, 117);
            this.PB7O.TabIndex = 36;
            this.PB7O.TabStop = false;
            this.PB7O.Visible = false;
            // 
            // PB7X
            // 
            this.PB7X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB7X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB7X.Location = new System.Drawing.Point(7, 321);
            this.PB7X.Name = "PB7X";
            this.PB7X.Size = new System.Drawing.Size(179, 117);
            this.PB7X.TabIndex = 37;
            this.PB7X.TabStop = false;
            this.PB7X.Visible = false;
            // 
            // PB8X
            // 
            this.PB8X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB8X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB8X.Location = new System.Drawing.Point(216, 321);
            this.PB8X.Name = "PB8X";
            this.PB8X.Size = new System.Drawing.Size(179, 117);
            this.PB8X.TabIndex = 38;
            this.PB8X.TabStop = false;
            this.PB8X.Visible = false;
            // 
            // PB9X
            // 
            this.PB9X.BackgroundImage = global::Final.Properties.Resources.x;
            this.PB9X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB9X.Location = new System.Drawing.Point(422, 321);
            this.PB9X.Name = "PB9X";
            this.PB9X.Size = new System.Drawing.Size(179, 117);
            this.PB9X.TabIndex = 39;
            this.PB9X.TabStop = false;
            this.PB9X.Visible = false;
            // 
            // PB8O
            // 
            this.PB8O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB8O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB8O.Location = new System.Drawing.Point(216, 321);
            this.PB8O.Name = "PB8O";
            this.PB8O.Size = new System.Drawing.Size(179, 117);
            this.PB8O.TabIndex = 40;
            this.PB8O.TabStop = false;
            this.PB8O.Visible = false;
            // 
            // PB9O
            // 
            this.PB9O.BackgroundImage = global::Final.Properties.Resources.o;
            this.PB9O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PB9O.Location = new System.Drawing.Point(422, 321);
            this.PB9O.Name = "PB9O";
            this.PB9O.Size = new System.Drawing.Size(179, 117);
            this.PB9O.TabIndex = 41;
            this.PB9O.TabStop = false;
            this.PB9O.Visible = false;
            // 
            // column1Win
            // 
            this.column1Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.column1Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.column1Win.Location = new System.Drawing.Point(7, 48);
            this.column1Win.Name = "column1Win";
            this.column1Win.Size = new System.Drawing.Size(598, 23);
            this.column1Win.TabIndex = 42;
            this.column1Win.Visible = false;
            // 
            // row2Win
            // 
            this.row2Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.row2Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.row2Win.Location = new System.Drawing.Point(298, -1);
            this.row2Win.Name = "row2Win";
            this.row2Win.Size = new System.Drawing.Size(18, 452);
            this.row2Win.TabIndex = 45;
            this.row2Win.Visible = false;
            // 
            // row3Win
            // 
            this.row3Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.row3Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.row3Win.Location = new System.Drawing.Point(507, 1);
            this.row3Win.Name = "row3Win";
            this.row3Win.Size = new System.Drawing.Size(18, 452);
            this.row3Win.TabIndex = 46;
            this.row3Win.Visible = false;
            // 
            // row1Win
            // 
            this.row1Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.row1Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.row1Win.Location = new System.Drawing.Point(85, 1);
            this.row1Win.Name = "row1Win";
            this.row1Win.Size = new System.Drawing.Size(18, 452);
            this.row1Win.TabIndex = 47;
            this.row1Win.Visible = false;
            // 
            // column3Win
            // 
            this.column3Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.column3Win.Location = new System.Drawing.Point(6, 374);
            this.column3Win.Name = "column3Win";
            this.column3Win.Size = new System.Drawing.Size(598, 23);
            this.column3Win.TabIndex = 48;
            this.column3Win.Visible = false;
            // 
            // column2Win
            // 
            this.column2Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.column2Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.column2Win.Location = new System.Drawing.Point(6, 214);
            this.column2Win.Name = "column2Win";
            this.column2Win.Size = new System.Drawing.Size(598, 23);
            this.column2Win.TabIndex = 49;
            this.column2Win.Visible = false;
            // 
            // pb1Win
            // 
            this.pb1Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pb1Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pb1Win.Location = new System.Drawing.Point(12, 48);
            this.pb1Win.Name = "pb1Win";
            this.pb1Win.Size = new System.Drawing.Size(179, 23);
            this.pb1Win.TabIndex = 50;
            this.pb1Win.Visible = false;
            // 
            // pb5Win
            // 
            this.pb5Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pb5Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pb5Win.Location = new System.Drawing.Point(216, 214);
            this.pb5Win.Name = "pb5Win";
            this.pb5Win.Size = new System.Drawing.Size(179, 23);
            this.pb5Win.TabIndex = 51;
            this.pb5Win.Visible = false;
            // 
            // pb9Win
            // 
            this.pb9Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pb9Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pb9Win.Location = new System.Drawing.Point(426, 374);
            this.pb9Win.Name = "pb9Win";
            this.pb9Win.Size = new System.Drawing.Size(173, 23);
            this.pb9Win.TabIndex = 52;
            this.pb9Win.Visible = false;
            // 
            // pb3Win
            // 
            this.pb3Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pb3Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pb3Win.Location = new System.Drawing.Point(422, 48);
            this.pb3Win.Name = "pb3Win";
            this.pb3Win.Size = new System.Drawing.Size(182, 23);
            this.pb3Win.TabIndex = 53;
            this.pb3Win.Visible = false;
            // 
            // pb7Win
            // 
            this.pb7Win.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pb7Win.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pb7Win.Location = new System.Drawing.Point(12, 374);
            this.pb7Win.Name = "pb7Win";
            this.pb7Win.Size = new System.Drawing.Size(173, 23);
            this.pb7Win.TabIndex = 54;
            this.pb7Win.Visible = false;
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 450);
            this.Controls.Add(this.pb7Win);
            this.Controls.Add(this.pb3Win);
            this.Controls.Add(this.pb9Win);
            this.Controls.Add(this.pb5Win);
            this.Controls.Add(this.pb1Win);
            this.Controls.Add(this.column2Win);
            this.Controls.Add(this.column3Win);
            this.Controls.Add(this.row1Win);
            this.Controls.Add(this.row3Win);
            this.Controls.Add(this.row2Win);
            this.Controls.Add(this.column1Win);
            this.Controls.Add(this.PB9O);
            this.Controls.Add(this.PB8O);
            this.Controls.Add(this.PB9X);
            this.Controls.Add(this.PB8X);
            this.Controls.Add(this.PB7X);
            this.Controls.Add(this.PB7O);
            this.Controls.Add(this.PB6X);
            this.Controls.Add(this.PB6O);
            this.Controls.Add(this.PB5O);
            this.Controls.Add(this.PB5X);
            this.Controls.Add(this.PB9Test);
            this.Controls.Add(this.PB8Test);
            this.Controls.Add(this.PB6Test);
            this.Controls.Add(this.PB5Test);
            this.Controls.Add(this.PB4X);
            this.Controls.Add(this.PB3O);
            this.Controls.Add(this.PB3X);
            this.Controls.Add(this.PB3Test);
            this.Controls.Add(this.PB2O);
            this.Controls.Add(this.PB4O);
            this.Controls.Add(this.PB2X);
            this.Controls.Add(this.PB2Test);
            this.Controls.Add(this.PB1X);
            this.Controls.Add(this.PB1O);
            this.Controls.Add(this.PB1Test);
            this.Controls.Add(this.PB4Test);
            this.Controls.Add(this.PB7Test);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Name = "GameForm";
            this.Text = "GameForm";
            this.Load += new System.EventHandler(this.GameForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PB7Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB1X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB2O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB3O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB4X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB9Test)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB5O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB6X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB7O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB7X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB9X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB8O)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB9O)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Label label4;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox PB7Test;
        private PictureBox PB4Test;
        private PictureBox PB1Test;
        private PictureBox PB1O;
        private PictureBox PB1X;
        private PictureBox PB2Test;
        private PictureBox PB2X;
        private PictureBox PB4O;
        private PictureBox PB2O;
        private PictureBox PB3Test;
        private PictureBox PB3X;
        private PictureBox PB3O;
        private PictureBox PB4X;
        private PictureBox PB5Test;
        private PictureBox PB6Test;
        private PictureBox PB8Test;
        private PictureBox PB9Test;
        private PictureBox PB5X;
        private PictureBox PB5O;
        private PictureBox PB6O;
        private PictureBox PB6X;
        private PictureBox PB7O;
        private PictureBox PB7X;
        private PictureBox PB8X;
        private PictureBox PB9X;
        private PictureBox PB8O;
        private PictureBox PB9O;
        public Label column1Win;
        private Label row2Win;
        private Label row3Win;
        private Label row1Win;
        private Label column3Win;
        public Label column2Win;
        private Label pb1Win;
        private Label pb5Win;
        private Label pb9Win;
        private Label pb3Win;
        private Label pb7Win;
    }
}